//
//  main.cpp
//  HW_1_1C
//
//  Created by Natálie Stepankevyčová on 4/14/19.
//  Copyright © 2019 Natálie Stepankevyčová. All rights reserved.
//

/***
 22B - PROGRAM 1C: Parallel Arrays and Binary Search
 BINARY SEARCH
 
 If found, display the gpa and major, otherwise display an error message. Keep track of the number of searches for each student in another array. When done searching, write the arrays to an output file named
 
 Written by: Natalie Stepankevycova
 IDE: Xcode
 
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <fstream>
#include <cstdlib>

using namespace std;

// Function prototypes


int readStuData(string[], float[], string[], int);
int binarySearch(string[], int, string);
void writeDataToFile(string[], float[], int[], string[], int);


int main()
{
    
    const int STUDENTS = 5000;      // maximum size of arrays
    string IdData[STUDENTS]= {};        // array of student ID
    float studentGPA[STUDENTS]= {};        // array of student GPAs
    string majors[STUDENTS] = {};       // array of students' major
    static int searchCounter[STUDENTS] = {0};
    int size = 0;
    int sizeOfArray = readStuData(IdData, studentGPA, majors, size);
    char again;
    
    string valueSearchedFor;        // stores user's input
    
    readStuData(IdData, studentGPA, majors, size);
    
    if (sizeOfArray == 5000){
        cout << "The file contains more than 5000 lines!";
        return 0;
    }
    
    do {
        cout << "Please enter student ID (in format '2ABCD'): ";
        
        getline(cin, valueSearchedFor);
        
        // declaring position of found value or returning -1
        int valueFound = binarySearch(IdData, sizeOfArray, valueSearchedFor);
        
        
        if (valueFound == -1){
            cout << "Value you searched for was not foud.";
        }
        else{
            searchCounter[valueFound]++;
            cout << "Value you searched for: " << valueSearchedFor
            << endl << studentGPA[valueFound] << "\t"
            << majors[valueFound] << endl;
            
        }
        // asking user if he/she wants to continue searching
        cout << "Do you want to continue searching? (Y/N): ";
        cin >> again;
        cin.ignore();
    } while (again == 'y' || again == 'Y');
    
    
    writeDataToFile(IdData, studentGPA, searchCounter, majors, sizeOfArray);
    
    
    
    return 0;
}



int readStuData(string IdData[], float studentGPA[],
                string majors[], int size){
    
    size = 0;
    ifstream infile;
    
    string line;
    infile.open("students.txt");
    
    if (!infile)
        cout << "FILE NOT FOUND";
    
    
    while (infile >> IdData[size] >> studentGPA[size] )
    {
        infile.ignore();
        getline(infile, majors[size]);
        size++;
        
    }
     
    size--;

    infile.close();
    
    return size;
}



int binarySearch(string IdData[], int sizeOfArray, string valueSearchedFor)
{
    int first = 0,         // First array element
    last = sizeOfArray - 1, // Last array element
    middle,                 // Midpoint of search
    position = -1;         // Position of search value
    // Assume not found
    
    while ( position == -1 && first <= last)
    {
        middle = (first + last) / 2;  // Calculate midpoint
        if (IdData[middle] == valueSearchedFor)      // If value is found at mid
        {
            position = middle;
        }
        else if (IdData[middle] > valueSearchedFor) // If value is in lower half
            last = middle - 1;
        else
            first = middle + 1;            // If value is in upper half
    }
    return position;
}

// printing data to Out.txt file
void writeDataToFile(string IdData[], float studentGPA[],
                     int searchCounter[], string majors[], int sizeOfArray){
    
    ofstream myfile ("out.txt");    // creating new file to write to
    
    
    if (myfile.is_open())           // validating file
    {
        myfile << "\n=== The statistics ===" << endl;
        
        // writing array to file 
        for(int i = 0; i < sizeOfArray; i ++)
        {
            
            myfile << setprecision(1) << fixed
            << searchCounter[i] << "\t" << IdData[i] << "\t"
            << majors[i] << "\t" << "(" << studentGPA[i]
            << ")" <<  endl;
        }
    }
    else{
        cout << "Unable to open file";
    }
    
    myfile.close();
}



/****************** OUTPUT ******************
 
 Please enter student ID (in format '2ABCD'): 2ABCD
 Value you searched for: 2ABCD
 2.5     Marketing
 Do you want to continue searching? (Y/N): Y
 Please enter student ID (in format '2ABCD'): 2ABCD
 Value you searched for: 2ABCD
 2.5     Marketing
 Do you want to continue searching? (Y/N): Y
 Please enter student ID (in format '2ABCD'): 2ABCD
 Value you searched for: 2ABCD
 2.5     Marketing
 Do you want to continue searching? (Y/N): Y
 Please enter student ID (in format '2ABCD'): 2ABCD
 Value you searched for: 2ABCD
 2.5     Marketing
 Do you want to continue searching? (Y/N): Y
 Please enter student ID (in format '2ABCD'): 2ABCD
 Value you searched for: 2ABCD
 2.5     Marketing
 Do you want to continue searching? (Y/N): N
 Program ended with exit code: 0
 
 */




