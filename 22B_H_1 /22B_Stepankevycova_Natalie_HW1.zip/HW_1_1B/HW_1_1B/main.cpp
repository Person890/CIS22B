//
//  main.cpp
//  HW_1_1B
//
//  Created by Natálie Stepankevyčová on 4/12/19.
//  Copyright © 2019 Natálie Stepankevyčová. All rights reserved.
//

/***
 22B - PROGRAM 1B:
 INSERTION SORT
 
 Find and fix errors. Run the program once and save the output as a comment at the end
 of the source file.
 
 Changed by: Natalie Stepankevycova
 IDE: Xcode
 
 */

#include <iostream>
#include <iomanip>

using namespace std;

void insertionSort(double [], int);

int main()
{
    double list[100] = {50.1, 30.2, 80.3, 10.5, 30.2, 40.9, 90.8, 30.2, 80.8, 30.5};
    int size = 10;
    
    // print out original array
    for (int i = 0; i < size; i++)
    {
        cout << list[i] << " ";
    }
    cout << endl;
    
    insertionSort(list, size);  // calling sort function
    
    // print out sorted array
    for (int i = 0; i < size; i++)
    {
        cout << setprecision(1) << fixed <<  list[i] << " ";
    }
    cout << endl;
    
    return 0;
}

/***************************************************
 This function sorts an array in descending order
 using the Insertion Sort algorithm
 */
void insertionSort(double list[], int size)
{
    int temp;   // temporary copy
    int curr;
    double walk;
    
    for (temp = 1; temp < size; temp++) {
        walk = list[temp];
        curr = temp - 1;
        
        /* Move elements of arr[0..i-1], that are
         greater than key, to one position ahead
         of their current position */
        while (curr >= 0 && list[curr] > walk) {
            list[curr + 1] = list[curr];
            curr = curr - 1;
        }
        list[curr + 1] = walk;
       
        }
   

}

/****************** OUTPUT
 
 50.1 30.2 80.3 10.5 30.2 40.9 90.8 30.2 80.8 30.5
 10.5 30.2 30.2 30.2 30.5 40.9 50.1 80.3 80.8 90.8
 Program ended with exit code: 0
 
 */
