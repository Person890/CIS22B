// Specification file for the City class
// Written By: Natalie Stepankevycova
// IDE:        Xcode

#ifndef CITY_H
#define CITY_H

struct City
{
    char state [2];
    std::string city;
    int year;
};



#endif
