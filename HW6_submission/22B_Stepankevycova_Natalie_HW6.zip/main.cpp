//
//  main.cpp
//  22B_6_C
//
//  Created by Natálie Stepankevyčová on 6/3/19.
//  Copyright © 2019 Natálie Stepankevyčová. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
